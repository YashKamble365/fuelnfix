const { Cashfree, CFEnvironment } = require('cashfree-pg');

Cashfree.XClientId = "TEST10833975494424fc8c4f7e69376857933801";
Cashfree.XClientSecret = "cfsk_ma_test_946b90ae5c81469120516f1d6978cae9_0becf0c3";
Cashfree.XEnvironment = CFEnvironment.SANDBOX;

async function test() {
    try {
        const cashfree = new Cashfree(
            CFEnvironment.SANDBOX,
            "TEST10833975494424fc8c4f7e69376857933801",
            "cfsk_ma_test_946b90ae5c81469120516f1d6978cae9_0becf0c3"
        );
        // Mocking the actual call which would fail due to network/params, but checking if it throws AUTH error immediately
        // Actually, let's try to inspect the instance's axios interceptors or config if possible, 
        // or just try to make a call with minimal dummy data and see if we get 401 or 400 (Bad Request).
        // 400 means Auth passed. 401 means Auth failed.

        const request = {
            order_amount: 1,
            order_currency: "INR",
            order_id: "TEST_" + Date.now(),
            customer_details: { customer_id: "123", customer_phone: "9999999999" }
        };

        console.log("Attempting call...");
        await cashfree.PGCreateOrder("2023-08-01", request).catch(e => {
            console.log("Error Code:", e.response?.status);
            console.log("Error Data:", e.response?.data);
        });

    } catch (e) {
        console.log("Fatal:", e);
    }
}

test();
